"""Independent arithmetic/artifact audit. Read-only inputs; no inference or tuning."""
import base64, hashlib, json, math, re, statistics, sys
from pathlib import Path
from collections import Counter
BASE = Path(__file__).resolve().parent.parent
REPO = BASE.parents[2]
sys.path.insert(0, str(REPO/'eval/specialist-intent'))
import adapters, binder, evidence, runner
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
RUN=BASE/'run'; freeze=runner.verify_run(RUN); selection=runner.verify_selection(RUN)
report_path=sorted(RUN.glob('reports/*/summary.json'))[-1]; report=read(report_path)
assert all(sha(RUN/'source'/p)==h for p,h in freeze['sources'].items())
manifest=read(REPO/'eval/specialist-intent/fixtures/manifest.json')
DATA={split:{c['id']:c for c in runner.dataset(split)} for split in ['development','heldout']}
REQ={(x['id'],x['arm'],x['variant'],x['view']):x for x in read(RUN/'requests.json')}
EXAMPLES=read(REPO/'eval/query-routing/training.json')['examples']
CONFIG_KEYS={'arm','variant','threshold','margin','unfiltered'}
clean=lambda x:{k:v for k,v in x.items() if k in CONFIG_KEYS}

def independent(cases, rows, config):
    indexed={r['id']:r for r in rows};assert len(indexed)==len(rows) and set(indexed)<=set(cases)
    totals=Counter();outcomes={};times=[]
    for ident,c in cases.items():
        row=indexed.get(ident,{'status':'unattempted'});status=row['status'];op=row.get('operation')
        if status=='selected' and row.get('scores') and not config.get('unfiltered'):
            scores=sorted(row['scores'].values(),reverse=True)
            if row.get('top_score',scores[0])<config.get('threshold',0) or row.get('margin',scores[0]-scores[1])<config.get('margin',0):status='deferred'
        valid=status in ['selected','deferred'];correct=valid and op==c['gold']['operation'];accepted=status=='selected'
        actual=binder.bind(c['input']['query'],op,c['input']['catalog']) if accepted else None
        complete=bool(accepted and correct and actual=={k:c['gold'][k] for k in ['readiness','options','executable']})
        for name,value in {'valid':valid,'raw_correct':correct,'accepted_correct':accepted and correct,'wrong_accepted':accepted and not correct,'wrong_specialized':accepted and op!='no_override' and c['gold']['operation']=='no_override','complete_correct':complete,'executable_correct':complete and c['gold']['executable'],'deferred':status=='deferred','errors':status=='error','unattempted':status=='unattempted'}.items():totals[name]+=int(value)
        outcomes[ident]={'outcome':op if accepted else status,'wrong_specialized':accepted and op!='no_override' and c['gold']['operation']=='no_override'}
        if valid:times.append(row['http_ms'] if 'http_ms' in row else None)
    totals['total']=len(cases)
    real_times=[x for x in times if x is not None]
    totals['latency_samples']=len(real_times)
    totals['median_ms']=statistics.median(real_times) if real_times else None
    totals['p95_ms']=sorted(real_times)[math.ceil(.95*len(real_times))-1] if real_times else None
    return dict(totals),outcomes

eligible=lambda m:m['valid']==m['total'] and m['wrong_accepted']<=1 and m['wrong_specialized']==0
all_rows={};completed=[];resource_observations={};response_count=0
for stage in ['development','primary','sensitivity']:
    for arm in (runner.MODELS if stage=='sensitivity' else runner.ARMS):
        p=RUN/stage/arm;completion=read(p/'completion.json');rows=read(p/'rows.json');planned=read(p/'planned.json')
        assert sha(p/'rows.json')==completion['rows_sha256'];assert len(rows)==len(planned)==completion['planned']
        assert [json.loads(x) for x in (p/'journal.jsonl').read_text().splitlines()]==rows
        assert sum(r['status'] in ['selected','deferred'] for r in rows)==completion['valid'];assert completion['stop_reason'] is None
        for row in rows:
            assert row['attempted'] is True
            if arm=='code':
                if 'driver_sha256' in row:assert row['driver_sha256']==freeze['driver_sha256']
                continue
            ident=row['id'] if not row['id'].startswith('warmup-') else next(iter(DATA['development']))
            req=REQ[(ident,arm,row['variant'],row['view'])]
            assert row['request_sha256']==req['payload_sha256']
            raw=base64.b64decode(row['response_base64']);assert hashlib.sha256(raw).hexdigest()==row['response_sha256'];assert json.loads(raw)==row['response'];response_count+=1
            if arm!='embeddings':
                decoded=adapters.decode_response(row['response'],arm,req['request']);assert all(decoded[k]==row[k] for k in ['status','operation','scores'])
            else:
                cosines=row['raw']['cosines'];best=max(range(len(cosines)),key=lambda i:cosines[i]);assert best==row['example_index'];assert row['operation']==EXAMPLES[best].get('operation',EXAMPLES[best].get('intent'))
        if arm in ['embeddings','gliclass','deberta']:
            obs=read(p/'resources-final.json');assert obs['rows_sha256']==completion['rows_sha256'] and obs['verified'] and not obs['oom']
            host=obs['inspect']['HostConfig'];assert host['NanoCpus']==4000000000 and host['Memory']==4294967296 and obs['inspect']['Image']==obs['container_digest']
            resource_observations[stage+'/'+arm]={k:obs[k] for k in ['peak_memory_bytes','readiness_seconds','cpu_time_seconds']}
        all_rows[(stage,arm)]=rows;completed.append((stage,arm,completion))

# Recompute development configuration choices without the scorer's grade/selection helpers.
code_configs=[]
for config in runner.configurations('code'):
    rows=[r for r in all_rows['development','code'] if r['configuration']==config]
    m,_=independent(DATA['development'],rows,config);code_configs.append((config,m))
bestcode=lambda entries:max(entries,key=lambda x:(x[1]['complete_correct'],x[1]['raw_correct']))
tuned=bestcode([x for x in code_configs if x[0]['arm']=='keyword_bm25_tuned']);assert tuned[0]['threshold']==selection['bm25']
code=bestcode([x for x in code_configs if x[0]['arm']!='keyword_bm25_tuned' or x==tuned]);assert code[0]==clean(selection['code'])
chosen={}
for arm in runner.ARMS[1:]:
    scored=[]
    for config in runner.configurations(arm):
        rows=[r for r in all_rows['development',arm] if r['phase']=='measured' and r['variant']==config['variant']]
        m,_=independent(DATA['development'],rows,config);scored.append((config,m))
    qualified=[x for x in scored if eligible(x[1])];best=max(qualified or scored,key=lambda x:(x[1]['accepted_correct'],x[1]['raw_correct']))
    assert best[0]==clean(selection[arm]);assert bool(qualified)==selection[arm]['eligible'];chosen[arm]=best
nominees=[(a,chosen[a]) for a in ['gliclass','deberta']];qualified=[x for x in nominees if eligible(x[1][1])]
nominee=max(qualified or nominees,key=lambda x:(x[1][1]['accepted_correct'],x[1][1]['raw_correct'],-x[1][1]['median_ms']))[0];assert nominee==selection['nominee']['arm']=='deberta'
primary={};primary_outcomes={}
for arm in runner.ARMS:
    configs=[x for x in runner.configurations('code') if x['arm']!='keyword_bm25_tuned' or x['threshold']==selection['bm25']] if arm=='code' else [clean(selection[arm])]
    for config in configs:
        rows=[r for r in all_rows['primary',arm] if r['phase']=='measured' and (arm!='code' or r['configuration']==config)]
        assert len(rows)==120 and {r['id'] for r in rows}==set(DATA['heldout'])
        m,outcomes=independent(DATA['heldout'],rows,config);name=config['arm'];primary[name]=m;primary_outcomes[name]=outcomes
        for k,v in m.items():assert report['metrics'][name][k]==v,(name,k,v,report['metrics'][name][k])
sensitivity={}
for arm in runner.MODELS:
    sensitivity[arm]={}
    for view in ['reverse','remap']:
        rows=[r for r in all_rows['sensitivity',arm] if r['phase']=='measured' and r['view']==view]
        subset={k:c for k,c in DATA['heldout'].items() if k in manifest['sensitivity']['case_ids']};assert len(rows)==24 and {r['id'] for r in rows}==set(subset)
        m,outcomes=independent(subset,rows,selection[arm]);changes=sum(v['outcome']!=primary_outcomes[arm][k]['outcome'] for k,v in outcomes.items());new=sum(v['wrong_specialized'] and not primary_outcomes[arm][k]['wrong_specialized'] for k,v in outcomes.items())
        sensitivity[arm][view]={'valid':m['valid'],'changes':changes,'new_wrong_specialized':new}
        if arm==nominee:assert report['sensitivities'][view]['changes']==changes and report['sensitivities'][view]['new_wrong_specialized']==new
# Full task-by-task cache accounting, without semantic output inspection in logs.
cache={}
for stage,expected in [('development',135),('primary',123),('sensitivity',51)]:
    p=REPO/'.enjoy-logs'/f'specialist-qwen-{stage}.log';tasks={}
    for number,line in enumerate(p.read_text().splitlines(),1):
        match=re.search(r'\| task (\d+) \| (.*)',line)
        if not match:continue
        tid=int(match[1]);event=match[2]
        if 'new prompt,' in event:tasks[tid]={'prompt':int(re.search(r'task.n_tokens = (\d+)',event)[1]),'new_line':number,'cache':[]}
        elif tid in tasks:
            t=tasks[tid]
            if 'cached n_tokens =' in event:t['cache'].append((number,int(re.search(r'cached n_tokens = (\d+)',event)[1])))
            if 'prompt eval time =' in event:t.update(evaluated=int(re.search(r'/\s+(\d+) tokens',event)[1]),eval_line=number)
            if 'stop processing:' in event:t.update(truncated=int(re.search(r'truncated = (\d+)',event)[1]),release_line=number)
    assert len(tasks)==expected
    assert all(t['cache'][0][1]==0 and t['prompt']==t['evaluated'] and t['truncated']==0 and t['new_line']<t['cache'][0][0]<t['eval_line']<t['release_line'] for t in tasks.values())
    cache[stage]={'tasks':len(tasks),'initial_zero_and_full_eval_and_untruncated':len(tasks),'log_sha256':sha(p),'task_line_evidence':tasks}
lifecycles=[]
for p in (BASE/'lifecycle').glob('*/result.json'):
    d=read(p);assert d['success'] and (d['cleanup'].get('container_shutdown_verified') or d['cleanup'].get('shutdown_verified'))
    lifecycles.append({'name':p.parent.name,'started_at':d['started_at'],'finished_at':d['finished_at'],'sha256':sha(p)})
lifecycles.sort(key=lambda x:x['started_at']);assert all(a['finished_at']<=b['started_at'] for a,b in zip(lifecycles,lifecycles[1:]))
first_primary=min(c['started_at'] for stage,arm,c in completed if stage=='primary');assert max(c['finished_at'] for stage,arm,c in completed if stage=='development')<selection['selected_at']<first_primary
budgets={a:{'cap_seconds':300 if a=='code' else 600 if a=='embeddings' else 1800,'remaining_seconds':runner.budget_remaining(RUN,a)} for a in runner.ARMS}
assert all(x['remaining_seconds']>0 for x in budgets.values())
assert report['verdict']=='keep the baseline' and report['load'] is None and not (RUN/'load').exists()
assert report['checks']['completeness'] and report['checks']['stability'] and not report['checks']['intent_quality'] and not report['checks']['cpu_service_cost']
print(json.dumps({'status':'PASS','primary':primary,'sensitivity':sensitivity,'budgets':budgets,'completed_lifecycles':len(lifecycles),'raw_http_responses_verified':response_count,'cache_tasks':{s:c['tasks'] for s,c in cache.items()}}))
AUDIT={'status':'PASS','reviewer':'/root/label_review','scope':'Independent result arithmetic, selection chronology, frozen artifacts, denominators, runtime-record consistency and log cache audit; no rerun or changes to outputs.','freeze_sha256':sha(RUN/'freeze.json'),'selection_sha256':sha(RUN/'selection.json'),'report_path':str(report_path.relative_to(REPO)),'report_sha256':sha(report_path),'audit_script_sha256':sha(Path(__file__)),'primary':primary,'sensitivity':sensitivity,'budgets':budgets,'resources':resource_observations,'selection_time':selection['selected_at'],'first_primary_started_at':first_primary,'completed_lifecycles':lifecycles,'raw_http_responses_verified':response_count,'qwen_cache':cache,'verdict':'keep the baseline','load_status':'unattempted; correctly withheld because prerequisite quality and CPU-cost advancement gates failed','limitations':read(BASE/'setup/execution-limitations.json')['historical_limitations']}
with (BASE/'setup/final-review.json').open('x') as f:json.dump(AUDIT,f,indent=2);f.write('\n')
