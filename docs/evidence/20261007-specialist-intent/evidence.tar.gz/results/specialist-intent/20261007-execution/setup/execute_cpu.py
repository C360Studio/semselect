#!/usr/bin/env python3
"""Run-owned lifecycle helper; no tuning or fixture inspection."""
import argparse, fcntl, json, os, signal, subprocess, sys, time, urllib.request
from pathlib import Path
REPO=Path('/Users/coby/Code/c360/semselect')
ROOT=REPO/'results/specialist-intent/20261007-execution'
sys.path.insert(0,str(REPO/'eval/specialist-intent'))
import evidence as e, resources, runner
IMAGE='sha256:7db4b05ba0eaf9d677935ccc93f6396c1693c94971bc8405d5fdc9ebee6f44b5'
def cmd(args):
    return subprocess.run(args,capture_output=True,text=True,timeout=15,check=True).stdout
def interrupt(sig,frame):
    raise TimeoutError('owned lifecycle interrupted or 32-minute deadline')
def main():
    p=argparse.ArgumentParser(); p.add_argument('arm',choices=['gliclass','deberta','embeddings']); p.add_argument('stage',choices=['ready','development','primary','sensitivity','load']); a=p.parse_args()
    ident=a.arm+'-'+a.stage
    log=REPO/'.enjoy-logs'/('specialist-'+ident+'.log')
    print(json.dumps({'pid':os.getpid(),'log':str(log)}),flush=True)
    f=log.open('x'); os.dup2(f.fileno(),1); os.dup2(f.fileno(),2)
    location=ROOT/'lifecycle'/ident; location.mkdir()
    record={'arm':a.arm,'stage':a.stage,'started_at':runner.now(),'pid':os.getpid(),'helper_sha256':e.digest(__file__)}
    proc=None; cid=None; started=time.monotonic()
    for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT): signal.signal(sig,interrupt)
    signal.alarm(1920)
    guard=(ROOT/'lifecycle/loaded-model.lock').open('a')
    try:
        fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for prior in (ROOT/'lifecycle').glob('*/launch.json'):
            if prior.parent==location:continue
            result=prior.parent/'result.json'
            if not result.exists():raise RuntimeError('prior lifecycle has no final cleanup record: '+str(prior.parent))
            cleanup=e.read(result).get('cleanup',{})
            if not (cleanup.get('container_shutdown_verified') or cleanup.get('shutdown_verified')):raise RuntimeError('prior shutdown unverified: '+str(prior.parent))
        record['prelaunch_inventory']={'docker':cmd(['docker','ps','--no-trunc','--format','{{json .}}']),'processes':cmd(['ps','-Ao','pid,pcpu,rss,comm'])}
        port={'gliclass':18091,'deberta':18092,'embeddings':18093}[a.arm]
        base=f'http://127.0.0.1:{port}'
        args=['docker','run','--cidfile',str(location/'container.cid'),'--name','semselect-specialist-'+ident,'--platform','linux/arm64','--cpus','4','--cpuset-cpus','0-3','--memory','4g','-p',f'127.0.0.1:{port}:{8099 if a.arm != "embeddings" else 8081}']
        if a.arm=='embeddings':
            env=e.read(ROOT/'setup/semembed-audit/environment-identity.json')
            image=env['container_digest']
            args += ['--mount',f'type=bind,src={ROOT}/setup/semembed-audit/model-cache,dst=/model-cache,readonly']
            for value in ['FASTEMBED_CACHE_DIR=/model-cache','HF_HOME=/model-cache','HF_ENDPOINT=http://127.0.0.1:9','SEMEMBED_PORT=8081','SEMEMBED_MODEL=Snowflake/snowflake-arctic-embed-s']:
                args+=['-e',value]
            args += [image]
            endpoint=base+'/v1/embeddings'
        else:
            lock=e.read(REPO/'eval/specialist-intent/locks'/f'{a.arm}.json')
            image=IMAGE
            env={'model_revision':lock['revision'],'artifacts':{k:v['sha256'] for k,v in lock['files'].items()},'dependencies':e.read(ROOT/'setup/corrective/installed.json')['dependencies'],'runtime_sha256':e.digest(ROOT/'setup/corrective/context/server.py'),'architecture':'linux/arm64','precision':'FP32','cpu_only':True,'cpus':4,'threads':4,'memory_limit_bytes':4294967296,'query_batch_size':1,'container_digest':image}
            if a.arm=='deberta':env['pair_batch_size']=9
            args += ['--mount',f'type=bind,src={ROOT}/setup/corrective/models/{a.arm},dst=/model,readonly',image,'--arm',a.arm,'--model-dir','/model','--port','8099']
            endpoint=base+'/classify'
        record['command']=args; e.save_new(location/'launch.json',record)
        proc=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT)
        record['docker_cli_pid']=proc.pid
        deadline=started+120
        health=None
        while time.monotonic()<deadline:
            if proc.poll() is not None: raise RuntimeError('runtime exited before readiness: '+str(proc.returncode))
            try:
                with urllib.request.urlopen(base+'/health',timeout=1) as response:
                    health=json.load(response)
                break
            except Exception:time.sleep(.2)
        else:raise TimeoutError('readiness exceeded 120 seconds')
        env.update(readiness_seconds=time.monotonic()-started,endpoint=endpoint,container_id=(location/'container.cid').read_text().strip())
        cid=env['container_id']; observation=resources.capture(env)
        env.update(idle_memory_bytes=observation['current_memory_bytes'],peak_memory_bytes=observation['peak_memory_bytes'],peak_includes_startup=True,cpu_time_seconds=observation['cpu_time_seconds'],oom=observation['oom'],startup_log_sha256=e.digest(log),background_contention=[{'prelaunch_inventory':str(location/'launch.json'),'measurement':'snapshot only; no claim of otherwise idle host'}],cleanup={'status':'owned runtime active; final shutdown recorded in '+str(location/'result.json')},verified=observation['verified'])
        e.verify_environment(env,a.arm)
        e.save_new(location/'environment.json',env); e.save_new(location/'ready-resources.json',observation)
        record['health']=health; record['readiness_seconds']=env['readiness_seconds']
        if a.stage != 'ready':
            tokens=ROOT/'setup'/f'tokens-{a.arm}.json'
            if a.arm=='embeddings' and not tokens.exists():
                helper=ROOT/'setup/semembed-audit/tokenizer-preflight.py'
                subprocess.run([sys.executable,str(helper),str(location/'environment.json'),str(tokens)],check=True,timeout=120,stdout=f,stderr=subprocess.STDOUT)
            if a.stage=='load':record['completion']=runner.load_check(ROOT/'run',endpoint,location/'environment.json',tokens)
            else:record['completion']=runner.run_stage(ROOT/'run',a.stage,a.arm,endpoint,location/'environment.json',tokens)
        record['final_resources']=resources.capture(env)
        record['success']=True
    except Exception as exc:
        record.update(success=False,error=type(exc).__name__+': '+str(exc))
        import traceback;traceback.print_exc()
    finally:
        signal.alarm(0)
        try:
            cidfile=location/'container.cid'
            if cidfile.exists():
                cid=cidfile.read_text().strip()
                from supervise import cleanup_container
                record['cleanup']=cleanup_container(cidfile)
                record['stopped_inspect']=json.loads(cmd(['docker','inspect',cid]))[0]
            else:record['cleanup']={'container_shutdown_verified':proc is None}
        except Exception as exc:record['cleanup']={'container_shutdown_verified':False,'error':repr(exc)}
        try:
            if proc:
                try:proc.wait(timeout=15)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
                record['docker_exit_code']=proc.returncode
        except Exception as exc:record['cleanup']['cli_reap_error']=repr(exc)
        finally:
            record['success']=record.get('success',False) and record['cleanup'].get('container_shutdown_verified',False) and 'cli_reap_error' not in record['cleanup']
            record['elapsed_seconds']=time.monotonic()-started;record['finished_at']=runner.now();record['log_sha256']=e.digest(log)
            e.save_new(location/'result.json',record);guard.close()
            print(json.dumps({k:v for k,v in record.items() if k in ['success','error','elapsed_seconds','completion']}),flush=True)
    return 0 if record.get('success') else 1
if __name__=='__main__':sys.exit(main())
