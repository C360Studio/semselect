# Independent run-specific lifecycle review

Status: **PASS, prospective helper review** for the exact hashes below. Reviewer `/root/label_review` did not author or modify the helpers. Only this record and its JSON counterpart were written. No candidate/model outputs were inspected and no inference was performed by the reviewer. This is a review of lifecycle measurement/control code plus already-recorded specialist readiness/cleanup evidence, not a claim of inference quality or whole-run completion.

## Findings resolved before the reviewed helper snapshot

Initial code could let cleanup exceptions skip result persistence and could return success despite unverified Docker shutdown. It also lacked a shared model-lifecycle guard, asserted empty background contention without measurement, and retained only a readiness-time Qwen resource summary. These were raised promptly to the implementation owner and corrected outside the frozen scorer/payload source.

The revised CPU helper catches container-cleanup and CLI-reap failures separately, persists final result evidence and marks success only after verified container shutdown and successful CLI reap. The native helper similarly records shutdown exceptions and requires a reaped process. Both close their shared nonblocking file lock only after cleanup/result handling. All prior launch records must have verified cleanup records before another owned model launch. The guard coordinates these two helpers; it does not control unrelated external processes. Prelaunch Docker/process inventories record external contention as a snapshot without claiming an otherwise idle host.

CPU launch pins the image and model artifacts, read-only model/cache mounts, actual Linux ARM64, four CPUs plus CPU affinity, a 4-GiB memory limit and host-loopback publishing. Readiness is bounded at 120 seconds; the outer lifecycle alarm is 1,920 seconds. Actual Docker identity, ports, CPU/memory limits, running/OOM state and cgroup observations are obtained through the reviewed resource collector before inference. Peak cgroup memory includes container startup. The frozen runner supplies cumulative measured inference budgets, per-call deadlines, stop persistence, exact token checks and stage barriers. These helpers do not alter prompts, labels, thresholds, bindings or scoring.

The native helper verifies the existing Qwen model/runtime artifacts, clears LLAMA_ARG overrides, requires the 4,096-token context and one slot, and confirms complete Metal offload from the runtime log. It retains full-stage RSS/CPU samples, sampler errors and a final summary. These are sampled process RSS measurements: Metal unified allocations and between-sample peaks are not measured. Cache-disabling flags are supplied, but verification remains explicitly false and must remain a disclosed timing confound. The saved environment resource values are readiness-time observations; the lifecycle resource_summary is the full-stage summary.

Neither helper logs heldout query text or gold for tuning: query preparation/calls remain within the frozen runner/preflight path, while helper output concerns lifecycle/completion metadata. Actual per-stage runtime and token gates still apply.

## Observed readiness evidence and limitations

Read only the existing GLiClass/DeBERTa ready-stage records, not any development classification rows. Both records report readiness at approximately 3.70 seconds, successful owned Docker cleanup, and stopped-container inspections showing Running=false. Docker exit137 after the deliberate stop is consistent with the recorded bounded stop escalation and is not an inference failure in these readiness-only records.

The owner disclosed that some development work had already run using the earlier helper snapshot while this review was underway. This approval is prospective and does not rewrite or independently validate those stages. In particular, earlier empty background_contention arrays are unmeasured, not evidence of an idle host; preserve that limitation. No payload/scoring freeze was changed by these helper corrections.

Validation performed by this reviewer: full source reading, Python AST parsing of both current helpers, and consistency checks on the two ready-stage shutdown records. No new Docker/native launches, failure injections, or real inference were run. Runtime health under a genuine wedge, actual host contention over time and every later shutdown still require recorded observations.

## Exact reviewed hashes

- `execute_cpu.py`: `2ac692a8ade7d17780a4252d509c0871e3749a2d5c007a368cafca6bb8732760`
- `execute_qwen.py`: `88cc64062737195d91a25b778489192738affd06795b0a3c85dea67d40c29f96`

Ready-record hashes:

- `gliclass-ready/result.json`: `7a5bc271019b706e5ece5f1f4ec9994b1cd400a1f7f5e21b6c4e6b5a69a013ed`
- `deberta-ready/result.json`: `b5bae73efe9859f20ab4465dccc68ce1b211381b58ae312662cadf240322d69d`


## Focused mock-only fault injection

Five tests passed (0 failed; final test execution 0.015 seconds). Tests are preserved in `lifecycle-review-fault-tests.py`, and the exact helper/test hashes, command, outcomes and scope are recorded in `lifecycle-review-fault-results.json`. The helper hashes remain unchanged from the reviewed snapshot.

Validated CPU and native lock refusal before any process or runner call; CPU cleanup exceptions still persist a failed result and reap the CLI; an explicit unverified Docker shutdown cannot return success even after an otherwise successful lifecycle; and native cleanup exceptions persist failed shutdown plus resource samples/summary. Both helpers return nonzero for these injected faults and close the shared guard.

All model/process launches, subprocess operations, HTTP, signal mutation, descriptor redirection, threads, lock operations and helper file I/O were mocked. No real Docker/native child, model, network call or inference ran. Tests inject OS lock refusal rather than exercising simultaneous real processes, and verify cleanup accounting rather than real kill mechanics. Only reviewer-owned `lifecycle-review-*` evidence and these review records were written.
