"""Reviewer-owned fault injection: no Docker/native launch, sockets, or inference."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

SETUP = Path(__file__).resolve().parent
EXPECTED = {
    'execute_cpu.py': '2ac692a8ade7d17780a4252d509c0871e3749a2d5c007a368cafca6bb8732760',
    'execute_qwen.py': '88cc64062737195d91a25b778489192738affd06795b0a3c85dea67d40c29f96',
}
MODULES = {}
for name, digest in EXPECTED.items():
    path = SETUP / name
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise RuntimeError('helper differs from reviewed bytes: ' + name)
    spec = importlib.util.spec_from_file_location('review_' + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    MODULES[name] = module
import supervise


class OneSampleEvent:
    def __init__(self):
        self.calls = 0
    def is_set(self):
        self.calls += 1
        return self.calls > 1
    def wait(self, timeout):
        return False
    def set(self):
        self.calls = 100


class ImmediateThread:
    def __init__(self, target, daemon):
        self.target = target
    def start(self):
        self.target()
    def join(self, timeout):
        pass


class LifecycleFaultTests(unittest.TestCase):
    def exercise(self, filename, fault):
        module = MODULES[filename]
        cpu = filename == 'execute_cpu.py'
        records = {}
        log = MagicMock()
        log.fileno.return_value = 77
        guard = MagicMock()
        process = MagicMock(pid=12345, returncode=0)
        process.poll.return_value = None
        process.wait.return_value = 0
        lock_refused = fault == 'lock_refusal'
        if fault == 'native_terminate_exception':
            process.terminate.side_effect = OSError('injected terminate failure')
        fake_lock = {'revision': 'a'*40, 'files': {'model': {'sha256': 'b'*64}},
                     'filename': 'model.gguf', 'sha256': 'b'*64,
                     'alias': 'qwen', 'runtime_revision': 'c'*40}
        def read(path):
            if path.name == 'installed.json':
                return {'dependencies': {'torch': '2.14.1+cpu'}}
            return fake_lock
        def save(path, value):
            # Freeze a copy at the actual save boundary, as JSON persistence does.
            records[str(path)] = json.loads(json.dumps(value))
        def opened(path, *args, **kwargs):
            return guard if path.name == 'loaded-model.lock' else log
        def exists(path):
            if path.name == 'container.cid':
                return cpu and not lock_refused
            return path.name == 'tokens-qwen.json'
        observation = {'current_memory_bytes': 10, 'peak_memory_bytes': 20,
                       'cpu_time_seconds': 1, 'oom': False, 'verified': True}
        with contextlib.ExitStack() as stack:
            def mocked(obj, attr, **kwargs):
                return stack.enter_context(patch.object(obj, attr, **kwargs))
            stack.enter_context(patch('sys.argv', [filename] + (['gliclass', 'ready'] if cpu else ['development'])))
            stack.enter_context(patch('builtins.print'))
            mocked(Path, 'mkdir', return_value=None)
            mocked(Path, 'open', autospec=True, side_effect=opened)
            mocked(Path, 'glob', return_value=[])
            mocked(Path, 'exists', autospec=True, side_effect=exists)
            mocked(Path, 'read_text', return_value='d'*64)
            mocked(module.os, 'dup2', return_value=None)
            mocked(module.signal, 'signal', return_value=None)
            mocked(module.signal, 'alarm', return_value=0)
            flock = mocked(module.fcntl, 'flock', side_effect=BlockingIOError('injected busy lock') if lock_refused else None)
            popen = mocked(module.subprocess, 'Popen', return_value=process)
            mocked(module.subprocess, 'run', return_value=SimpleNamespace(returncode=0, stdout='123 0:01.00', stderr=''))
            mocked(module.subprocess, 'check_output', return_value='mock inventory')
            mocked(module.urllib.request, 'urlopen', return_value=io.StringIO('{}'))
            mocked(module.e, 'read', side_effect=read)
            mocked(module.e, 'save_new', side_effect=save)
            mocked(module.e, 'digest', return_value='e'*64)
            mocked(module.e, 'verify_environment', side_effect=lambda env, arm: env)
            mocked(module.runner, 'now', return_value='2026-10-07T00:00:00Z')
            stage = mocked(module.runner, 'run_stage', return_value={'stop_reason': None})
            if cpu:
                mocked(module, 'cmd', side_effect=lambda args: '[{"State":{"Running":false}}]' if args[:2] == ['docker', 'inspect'] else 'mock inventory')
                mocked(module.resources, 'capture', return_value=observation)
                cleanup = mocked(supervise, 'cleanup_container',
                                 side_effect=OSError('injected Docker cleanup failure') if fault == 'docker_cleanup_exception' else None,
                                 return_value={'container_shutdown_verified': False})
            else:
                mocked(module.threading, 'Event', side_effect=OneSampleEvent)
                mocked(module.threading, 'Thread', side_effect=ImmediateThread)
                mocked(module.qr, '_artifacts', return_value={})
                mocked(module.qr, '_json_http', return_value={'default_generation_settings': {'n_ctx': 4096}, 'total_slots': 1})
                mocked(module.qr.metal, 'metal_offload', return_value='confirmed mocked offload')
                mocked(module.qr.metal, 'sha256', return_value='f'*64)
            status = module.main()
            final = next(v for k,v in records.items() if k.endswith('/result.json'))
            self.assertEqual(status, 1)
            self.assertFalse(final['success'])
            guard.close.assert_called_once()
            flock.assert_called_once()
            if lock_refused:
                popen.assert_not_called()
                stage.assert_not_called()
                self.assertTrue(final['cleanup'].get('container_shutdown_verified', final['cleanup'].get('shutdown_verified')))
                self.assertIn('busy lock', final['error'])
            else:
                popen.assert_called_once()
                self.assertFalse(final['cleanup'].get('container_shutdown_verified', final['cleanup'].get('shutdown_verified')))
                if cpu:
                    cleanup.assert_called_once()
                    process.wait.assert_called_once()
                else:
                    stage.assert_called_once()
                    process.terminate.assert_called_once()
                    self.assertEqual(final['resource_summary']['samples'], 1)
                    self.assertTrue(any(k.endswith('/memory-samples.json') for k in records))
                if fault.endswith('exception'):
                    self.assertIn('injected', final['cleanup']['error'])
                elif fault == 'docker_cleanup_unverified':
                    self.assertNotIn('error', final['cleanup'])
                    self.assertNotIn('error', final)
            return final

    def test_cpu_cleanup_exception_persists_failure_and_reaps_cli(self):
        self.exercise('execute_cpu.py', 'docker_cleanup_exception')

    def test_cpu_unverified_cleanup_cannot_return_success(self):
        self.exercise('execute_cpu.py', 'docker_cleanup_unverified')

    def test_cpu_busy_lock_refuses_launch(self):
        self.exercise('execute_cpu.py', 'lock_refusal')

    def test_native_cleanup_exception_persists_failure_and_samples(self):
        self.exercise('execute_qwen.py', 'native_terminate_exception')

    def test_native_busy_lock_refuses_launch(self):
        self.exercise('execute_qwen.py', 'lock_refusal')


if __name__ == '__main__':
    unittest.main(verbosity=2)
