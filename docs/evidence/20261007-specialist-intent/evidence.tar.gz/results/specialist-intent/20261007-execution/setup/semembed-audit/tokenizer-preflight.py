#!/usr/bin/env python3
"""Run embedding-only full-input preflight with isolated tokenizers 0.22.2.

Usage: python3 tokenizer-preflight.py MEASURED_ENVIRONMENT_JSON OUTPUT_JSON
All supplied paths must resolve inside this repository. No weights are loaded.
The parent owns the authorized evaluation and supplies real environment evidence.
"""
from pathlib import Path
import json
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
RUN = HERE.parents[1]/'run'
IMAGE = 'sha256:7db4b05ba0eaf9d677935ccc93f6396c1693c94971bc8405d5fdc9ebee6f44b5'


def inside(path):
    path = Path(path).resolve()
    if not path.is_relative_to(REPO):
        raise ValueError('preflight paths must be inside repository')
    return '/repo/' + str(path.relative_to(REPO))


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    environment, output = (Path(v).resolve() for v in sys.argv[1:])
    if not environment.is_file() or not output.parent.is_dir() or output.exists():
        raise ValueError('measured environment must exist, output parent must exist, and output must be new')
    inputs = RUN/'requests-embeddings.json'
    if not inputs.is_file():
        raise ValueError('prepared embedding request manifest is missing')
    model = HERE/'model-cache/models--snowflake--snowflake-arctic-embed-s/snapshots/e596f507467533e48a2e17c007f0e1dacc837b33'
    audit = inside(HERE)
    name = 'semselect-tokenizer-preflight-' + uuid.uuid4().hex[:12]
    command = ['docker', 'run', '--rm', '--name', name, '--network', 'none',
               '--cpus', '4', '--cpuset-cpus', '0-3', '--memory', '4g',
               '--user', '0:0', '--entrypoint', 'python',
               '-e', 'PYTHONPATH='+audit+'/tokenizer-site',
               '-v', str(REPO)+':/repo:ro',
               '-v', str(output.parent)+':'+inside(output.parent)+':rw',
               IMAGE, audit+'/tokenizer-helper.py', '--arm', 'embeddings',
               '--model-dir', inside(model), '--environment', inside(environment),
               '--runtime-audit', audit+'/runtime-tokenization-audit.json',
               '--requests', inside(inputs), '--output', inside(output)]
    started = time.monotonic()
    record = {'command': command, 'model_inference': False, 'deadline_seconds': 120}
    try:
        process = subprocess.run(command, capture_output=True, text=True, timeout=120)
        record.update(exit_code=process.returncode, stdout=process.stdout, stderr=process.stderr)
    except subprocess.TimeoutExpired as exc:
        record.update(exit_code=None, timed_out=True,
                      stdout=(exc.stdout or b'').decode(errors='replace'),
                      stderr=(exc.stderr or b'').decode(errors='replace'))
        # This unique name belongs solely to this helper invocation. Killing a
        # timed-out docker CLI alone does not guarantee the container exited.
        cleanup = subprocess.run(['docker', 'rm', '-f', name], capture_output=True, text=True, timeout=15)
        record['timeout_cleanup'] = {'exit_code': cleanup.returncode, 'stdout': cleanup.stdout, 'stderr': cleanup.stderr}
    finally:
        record['elapsed_seconds'] = time.monotonic() - started
        (HERE/('tokenizer-run-'+name.rsplit('-', 1)[1]+'.json')).write_text(json.dumps(record, indent=2)+'\n')
    if record.get('timed_out') or record['exit_code'] != 0:
        raise SystemExit('Embedding tokenizer preflight failed: '+record.get('stderr', 'deadline exceeded'))
    print('Embedding preflight complete with isolated tokenizers 0.22.2: '+str(output))


if __name__ == '__main__':
    main()
