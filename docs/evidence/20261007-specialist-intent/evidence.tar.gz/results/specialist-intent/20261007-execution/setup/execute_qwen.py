#!/usr/bin/env python3
"""Bounded pinned native Metal lifecycle; stages do not tune on heldout."""
import argparse, fcntl, importlib.util, json, os, signal, subprocess, sys, threading, time, urllib.request
from pathlib import Path
REPO=Path('/Users/coby/Code/c360/semselect');ROOT=REPO/'results/specialist-intent/20261007-execution'
sys.path.insert(0,str(REPO/'eval/specialist-intent'))
import evidence as e, runner, preflight
spec=importlib.util.spec_from_file_location('qwen_runtime',REPO/'eval/query-routing/runtime.py');qr=importlib.util.module_from_spec(spec);sys.modules[spec.name]=qr;spec.loader.exec_module(qr)
def interrupted(sig,frame):raise TimeoutError('owned lifecycle deadline/interruption')
def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['development','primary','sensitivity']);a=p.parse_args()
    ident='qwen-'+a.stage;location=ROOT/'lifecycle'/ident;location.mkdir()
    log=REPO/'.enjoy-logs'/('specialist-'+ident+'.log');print(json.dumps({'pid':os.getpid(),'log':str(log)}),flush=True)
    f=log.open('x');os.dup2(f.fileno(),1);os.dup2(f.fileno(),2)
    proc=None;record={'stage':a.stage,'started_at':runner.now(),'pid':os.getpid(),'helper_sha256':e.digest(__file__)};samples=[];sample_errors=[];thread=None;stop=threading.Event();started=time.monotonic()
    for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT):signal.signal(sig,interrupted)
    signal.alarm(1920)
    guard=(ROOT/'lifecycle/loaded-model.lock').open('a')
    try:
        fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for prior in (ROOT/'lifecycle').glob('*/launch.json'):
            if prior.parent==location:continue
            result=prior.parent/'result.json'
            if not result.exists():raise RuntimeError('prior lifecycle has no final cleanup record: '+str(prior.parent))
            cleanup=e.read(result).get('cleanup',{})
            if not (cleanup.get('container_shutdown_verified') or cleanup.get('shutdown_verified')):raise RuntimeError('prior shutdown unverified: '+str(prior.parent))
        record['prelaunch_inventory']={'docker':subprocess.check_output(['docker','ps','--no-trunc','--format','{{json .}}'],text=True,timeout=10),'processes':subprocess.check_output(['ps','-Ao','pid,pcpu,rss,comm'],text=True,timeout=10)}
        lock=e.read(REPO/'models.baseline.lock.json');qr._artifacts('metal','qwen_json',lock)
        args=[str(qr.metal.SERVER),'-m',str(REPO/'models'/lock['filename']),'--host','127.0.0.1','--port','18087','--alias',lock['alias'],'-ngl','99','-t','4','-tb','4','-c','4096','-b','1024','-ub','512','-np','1','--no-context-shift','--metrics','-lv','4','--no-cache-prompt','--cache-reuse','0','--cache-ram','0']
        record['command']=args;e.save_new(location/'launch.json',record)
        proc=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,env={k:v for k,v in os.environ.items() if not k.startswith('LLAMA_ARG_')})
        e.save_new(location/'child.json',{'pid':proc.pid,'log':str(log)})
        def sample():
            while not stop.is_set():
                try:
                    r=subprocess.run(['ps','-o','rss=,time=','-p',str(proc.pid)],capture_output=True,text=True,timeout=2)
                    if r.returncode==0 and r.stdout.strip():
                        rss,cpu=r.stdout.split();parts=cpu.split(':');seconds=float(parts[-1])+int(parts[-2])*60+(int(parts[-3])*3600 if len(parts)>2 else 0)
                        samples.append({'monotonic':time.monotonic(),'rss_bytes':int(rss)*1024,'cpu_seconds':seconds})
                    elif proc.poll() is None:sample_errors.append({'error':'ps failed','stderr':r.stderr})
                except Exception as exc:sample_errors.append({'error':repr(exc)})
                stop.wait(.1)
        thread=threading.Thread(target=sample,daemon=True);thread.start()
        while time.monotonic()-started<120:
            if proc.poll() is not None:raise RuntimeError('native runtime exited')
            try:
                with urllib.request.urlopen('http://127.0.0.1:18087/health',timeout=1) as r:json.load(r)
                break
            except Exception:time.sleep(.2)
        else:raise TimeoutError('readiness120s')
        readiness=time.monotonic()-started;props=qr._json_http('http://127.0.0.1:18087/props');e.save_new(location/'props.json',props)
        assert props['default_generation_settings']['n_ctx']==4096 and props.get('total_slots',1)==1
        record['gpu_offload']=qr.metal.metal_offload(log.read_text())
        env={'model_revision':lock['revision'],'artifacts':{lock['filename']:lock['sha256']},'dependencies':{'llama.cpp':lock['runtime_revision']},'runtime_revision':lock['runtime_revision'],'runtime_sha256':qr.metal.sha256(qr.metal.SERVER),'architecture':'darwin/arm64-metal','precision':'Q4_K_M','readiness_seconds':readiness,'idle_memory_bytes':samples[-1]['rss_bytes'],'peak_memory_bytes':max(s['rss_bytes'] for s in samples),'peak_includes_startup':True,'cpu_time_seconds':samples[-1]['cpu_seconds'],'oom':False,'startup_log_sha256':e.digest(log),'background_contention':[],'cleanup':'Owned native process; verified shutdown in lifecycle result.json','verified':True,'thinking':False,'prefix_cache_disabled_verified':False,'endpoint':'http://127.0.0.1:18087/v1/chat/completions','memory_measurement':'RSS sampled every100ms from process launch; does not measure total unified GPU memory; timing cache disabled flags, raw per-request logs retained'}
        env['background_contention']=[{'prelaunch_inventory':str(location/'launch.json'),'measurement':'snapshot only; no claim of otherwise idle host'}]
        e.verify_environment(env,'qwen');e.save_new(location/'environment.json',env)
        tokens=ROOT/'setup/tokens-qwen.json'
        if not tokens.exists():
            identity={'revision':env['model_revision'],'artifacts':env['artifacts'],'runtime_revision':env['runtime_revision']}
            records=[preflight.preflight_request(req,identity=identity,qwen_url='http://127.0.0.1:18087') for req in e.read(ROOT/'run/requests-qwen.json')]
            e.save_new(tokens,records)
        record['completion']=runner.run_stage(ROOT/'run',a.stage,'qwen',env['endpoint'],location/'environment.json',tokens)
        record['success']=True
    except Exception as exc:
        record.update(success=False,error=type(exc).__name__+': '+str(exc));import traceback;traceback.print_exc()
    finally:
        signal.alarm(0);stop.set()
        try:
            if proc:
                if proc.poll() is None:proc.terminate()
                try:proc.wait(timeout=5)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
                record['cleanup']={'pid':proc.pid,'exit_code':proc.returncode,'shutdown_verified':proc.poll() is not None}
            else:record['cleanup']={'shutdown_verified':True,'never_launched':True}
        except Exception as exc:record['cleanup']={'shutdown_verified':False,'error':repr(exc)}
        finally:
            if thread:thread.join(timeout=3)
            record['success']=record.get('success',False) and record['cleanup']['shutdown_verified']
            record['resource_summary']={'peak_rss_bytes':max((s['rss_bytes'] for s in samples),default=None),'cpu_time_seconds':max((s['cpu_seconds'] for s in samples),default=None),'samples':len(samples),'sampler_errors':sample_errors,'measurement':'RSS sampled from process launch through stage completion; GPU unified memory and between-sample peaks are not measured'}
            e.save_new(location/'memory-samples.json',samples)
            record.update(elapsed_seconds=time.monotonic()-started,finished_at=runner.now(),log_sha256=e.digest(log));e.save_new(location/'result.json',record);guard.close()
            print(json.dumps({k:v for k,v in record.items() if k in ['success','error','elapsed_seconds','completion']}),flush=True)
    return 0 if record.get('success') else 1
if __name__=='__main__':sys.exit(main())
