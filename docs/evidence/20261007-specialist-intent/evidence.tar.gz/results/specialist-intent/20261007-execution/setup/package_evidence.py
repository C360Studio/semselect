#!/usr/bin/env python3
"""Preserve completed run evidence without vendoring weights or wheel caches."""
import hashlib, io, json, tarfile
from pathlib import Path
REPO=Path('/Users/coby/Code/c360/semselect')
ROOT=REPO/'results/specialist-intent/20261007-execution'
OUT=REPO/'docs/evidence/20261007-specialist-intent'
OUT.mkdir(parents=True,exist_ok=True)
excluded={'__pycache__','wheels','models','model-cache','tokenizer-site','tokenizer-wheelhouse'}
files=[p for p in ROOT.rglob('*') if p.is_file() and not excluded.intersection(p.relative_to(ROOT).parts) and p.name not in {'semembed-binary','loaded-model.lock'} and p.suffix not in {'.pyc','.crate'}]
files += list((REPO/'.enjoy-logs').glob('specialist-*.log'))
manifest=[]
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for p in sorted(files):
        body=p.read_bytes();name=str(p.relative_to(REPO));sha=hashlib.sha256(body).hexdigest()
        manifest.append({'path':name,'sha256':sha,'bytes':len(body)})
        info=tarfile.TarInfo(name);info.size=len(body);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(body))
value={'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest,'omissions':['Large model weights, runtime binaries, wheel caches and copied cache metadata are omitted; immutable artifact and image hashes, exact dependency closures and acquisition/verification records are included.','Temporary compiled Python caches and duplicated downloaded Rust crate archives are omitted; audited extracted Rust sources remain included.']}
with (OUT/'manifest.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(files),'sha256':value['sha256']}))
