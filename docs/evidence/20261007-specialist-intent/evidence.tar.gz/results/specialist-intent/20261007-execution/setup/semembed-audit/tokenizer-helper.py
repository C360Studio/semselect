#!/usr/bin/env python3
"""Embedding token preflight with an isolated exact native tokenizer dependency.

No model session or weights are loaded. Without --audit, delegates arguments to
repository preflight.py after verifying the tokenizers 0.22.2 import identity.
"""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import platform
import runpy
import sys

HERE = Path(__file__).resolve().parent
SITE = HERE / 'tokenizer-site'
sys.path.insert(0, str(SITE))
import tokenizers

assert tokenizers.__version__ == '0.22.2', tokenizers.__version__
assert importlib.metadata.version('tokenizers') == '0.22.2'
assert Path(tokenizers.__file__).resolve().is_relative_to(SITE.resolve())
assert platform.machine() in ('aarch64', 'arm64') and sys.platform == 'linux'

if len(sys.argv) == 3 and sys.argv[1] == '--audit':
    from packaging.requirements import Requirement
    deps = []
    for raw in importlib.metadata.requires('tokenizers'):
        req = Requirement(raw)
        if req.marker and not req.marker.evaluate({'extra': ''}):
            continue
        version = importlib.metadata.version(req.name)
        assert version in req.specifier, (raw, version)
        deps.append({'name': req.name, 'requirement': str(req.specifier), 'installed_version': version})
    model = HERE/'model-cache/models--snowflake--snowflake-arctic-embed-s/snapshots/e596f507467533e48a2e17c007f0e1dacc837b33'
    tokenizer = tokenizers.Tokenizer.from_file(str(model/'tokenizer.json'))
    short = tokenizer.encode('Average temperature', add_special_tokens=True)
    assert short.ids[0] == 101 and short.ids[-1] == 102
    long_text = ' '.join(['sensor'] * 600)
    native = tokenizer.encode(long_text, add_special_tokens=True)
    assert len(native.ids) == 512
    tokenizer.no_truncation()
    full = tokenizer.encode(long_text, add_special_tokens=True)
    assert len(full.ids) == 602
    assert full.ids[0] == 101 and full.ids[-1] == 102
    report = {
        'verified': True, 'tokenizers_version': tokenizers.__version__,
        'tokenizers_import': tokenizers.__file__, 'python_version': platform.python_version(),
        'architecture': platform.system()+'/'+platform.machine(),
        'direct_runtime_dependencies': deps,
        'package_files_sha256': {str(p.relative_to(SITE)): hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in SITE.rglob('*') if p.is_file() and '__pycache__' not in str(p)},
        'installed_environment_versions': dict(sorted((d.metadata['Name'], d.version)
                                                       for d in importlib.metadata.distributions()
                                                       if d.metadata['Name'].lower() != 'tokenizers')) | {'tokenizers': tokenizers.__version__},
        'sample_tokens': short.tokens, 'sample_ids': short.ids,
        'synthetic_overlength_native_tokens': len(native.ids),
        'synthetic_overlength_no_truncation_tokens': len(full.ids),
        'special_token_ids': [101, 102], 'model_inference': False,
        'cohort_preflight_performed': False,
    }
    with Path(sys.argv[2]).open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: report[k] for k in ('verified', 'tokenizers_version', 'python_version', 'architecture', 'direct_runtime_dependencies', 'sample_tokens', 'synthetic_overlength_native_tokens', 'synthetic_overlength_no_truncation_tokens')}))
else:
    script = HERE.parents[4]/'eval/specialist-intent/preflight.py'
    assert script.is_file(), script
    sys.path.insert(0, str(script.parent))
    sys.argv[0] = str(script)
    runpy.run_path(str(script), run_name='__main__')
