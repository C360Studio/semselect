import json, os, pathlib, shutil, subprocess, sys, time

REPO = pathlib.Path('/Users/coby/Code/c360/semselect')
SOURCE = REPO/'eval/specialist-intent'
OUT = REPO/'results/specialist-intent/20261007-execution/setup/corrective'
OUT.mkdir()
BASE = 'python@sha256:bf44cdfcb76cd3b41e879bc058fc37ec5872002ccfde7fcb765e218cde0cd79c'
started = time.monotonic()
deadline = started + 1400
events = []

def run(command, label, seconds=1200):
    before = time.monotonic()
    with (OUT/(label+'.log')).open('x') as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=min(seconds, max(1, deadline-before)))
            events.append({'stage': label, 'command': command, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic()-before})
            if result.returncode:
                raise RuntimeError(label+' failed; see its retained log')
        finally:
            (OUT/'setup-events.json').write_text(json.dumps(events,indent=2)+'\n')

try:
    cid = OUT/'wheel-download.cid'
    command = ['docker','run','--platform','linux/arm64','--cpus','4','--memory','4g','--cidfile',str(cid),
               '--mount',f'type=bind,source={SOURCE},target=/experiment,readonly',
               '--mount',f'type=bind,source={OUT},target=/output',BASE,
               'python','-m','pip','download','--only-binary=:all:','--extra-index-url','https://download.pytorch.org/whl/cpu','-r','/experiment/requirements.txt','-d','/output/wheels']
    try:
        run(command,'wheel-download')
    finally:
        if cid.exists():
            ident=cid.read_text().strip()
            subprocess.run(['docker','stop','--time','2',ident],stdout=subprocess.DEVNULL,timeout=10)
            inspect=subprocess.run(['docker','inspect',ident],capture_output=True,timeout=10)
            (OUT/'wheel-container.json').write_bytes(inspect.stdout)
    run([sys.executable,str(SOURCE/'locks/prepare.py'),'wheels','--wheelhouse',str(OUT/'wheels'),'--output',str(OUT/'requirements.lock.txt')],'wheel-lock',60)
    context=OUT/'context'
    context.mkdir()
    for name in ('Dockerfile','adapters.py','preflight.py','server.py'):
        shutil.copyfile(SOURCE/name,context/name)
    shutil.copytree(SOURCE/'locks',context/'locks')
    shutil.copytree(OUT/'wheels',context/'wheels')
    shutil.copyfile(OUT/'requirements.lock.txt',context/'requirements.lock.txt')
    run(['docker','build','--platform','linux/arm64','--build-arg','PYTHON_IMAGE='+BASE,'--iidfile',str(OUT/'image.id'),'-t','semselect-specialist:20261007',str(context)],'image-build')
    for arm in ('gliclass','deberta'):
        run([sys.executable,str(SOURCE/'locks/prepare.py'),'model','--arm',arm,'--output',str(OUT/'models'/arm)],arm+'-acquire')
    status='prepared'
except BaseException as error:
    status='failed: '+str(error)
    raise
finally:
    (OUT/'setup-result.json').write_text(json.dumps({'status':status,'base_image':BASE,'elapsed_seconds':time.monotonic()-started,'shared_environment_setup_counts_against_each_specialist':True,'events':events},indent=2)+'\n')
