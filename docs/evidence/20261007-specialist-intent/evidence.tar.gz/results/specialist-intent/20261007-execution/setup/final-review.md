# Independent final result and protocol review

**PASS for consistency of the recorded result: keep the baseline.** The selected DeBERTa specialist does not meet the frozen quality or CPU-cost gates. This review does not recommend adding a backend and does not convert this authored pilot into a production benchmark.

Reviewer: `/root/label_review`, independent from fixture author, implementation and tuning owners. After selection and primary execution were frozen, review access was extended to completed result rows. No thresholds, outputs, fixtures, selection or scorer were edited; no inference was rerun. Reviewer-owned audit script and evidence are `setup/final-review.py` and `setup/final-review.json`. Audit execution took approximately0.45 seconds and used only local arithmetic and file reads.

## Freeze, selection and denominators

The preparation/source hashes and preserved source copies match. The independent pre-execution review still binds the exact preparation freeze. Selection SHA and all frozen development row/environment hashes match. Independently recomputed every development configuration choice using separate arithmetic rather than the scorer's grade/selection functions; the selected BM25 threshold, code winner, learned configurations and specialist nominee agree with the frozen choices.

The complete development stages finished before selection at **15:28:21.959711 UTC**; the first primary stage began at **15:28:31.406571 UTC**. The nominee is DeBERTa variant1, threshold0, margin0.2; code winner is improved_rules. No retrospective specialist choice was made.

Every primary arm/configuration retains exactly120 planned cases. Each learned primary arm has120 valid responses; the code winner also has120. Historical keyword and BM25 arms each retain six explicit errors, and those cases remain in their120-case denominators. No runtime error became a correct fallback. The learned stages contain separate warmup/feasibility rows; neither those repetitions nor sensitivity repetitions were pooled into primary accuracy.

Independent all-case arithmetic matches the generated report:

| Arm | Raw correct /120 | Correct accepted | Wrong accepted | Deferred | Errors | Complete correct | Executable correct |
|---|---:|---:|---:|---:|---:|---:|---:|
| keyword | 61 | 61 | 53 | 0 | 6 | 61 | 33 |
| keyword_bm25_default | 61 | 61 | 53 | 0 | 6 | 61 | 33 |
| keyword_bm25_tuned | 61 | 61 | 53 | 0 | 6 | 61 | 33 |
| improved_rules | 95 | 95 | 25 | 0 | 0 | 95 | 45 |
| embeddings | 34 | 0 | 0 | 120 | 0 | 0 | 0 |
| gliclass | 37 | 37 | 83 | 0 | 0 | 37 | 27 |
| deberta | 22 | 13 | 1 | 106 | 0 | 13 | 11 |
| qwen | 111 | 111 | 8 | 1 | 0 | 111 | 60 |

All primary arms have zero unattempted cases. The embedding baseline's zero correct accepted decisions is explained by the development-selected acceptance threshold deferring all120 cases; its unfiltered raw accuracy remains34/120. It is not reported as120 runtime errors. Historical native options are preserved separately; their errors concern conflicting native operations or unsupported SearchOptions fields and remain visible. Native complete-output counts do not substitute for shared-binder outcomes.

## Artifact and resource evidence

Verified1,125 recorded HTTP response byte/hash pairs, their request hashes against frozen payloads and canonical response decoding (including sensitivity mappings). Completed stage planned counts, journal rows, final rows and completion hashes agree. Raw model values remain preserved. Independent primary latency medians/p95 and success counts agree with the generated report; each learned primary cohort has120 successful latency samples.

CPU final resource records bind their stage rows, report no OOM, and retain actual Docker inspections consistent with four CPUs,4-GiB safety limits and the recorded image identities. For the selected specialist, the report's maximum recorded peak across stages is2,012,315,648 bytes, and maximum recorded readiness is4.193 seconds. Memory/readiness targets pass, but primary median1,134.27ms and p952,049.14ms exceed250/750ms respectively.

Measured ledger budgets remain below all caps: code about30.05/300 seconds, embeddings14.86/600, GLiClass99.34/1800, DeBERTa460.46/1800 and Qwen300.72/1800. Embedding index setup is included. The preserved setup records show the initial dependency attempt, one CPU-wheel correction and a pre-freeze harness-parser continuation; recorded shared setup work totals about162.70 seconds. This review does not equate that command-work sum with all elapsed engineering time.

All13 completed model lifecycle intervals are nonoverlapping by their recorded start/finish times and have verified owned shutdown records. Earlier lifecycle records lack measured contention snapshots; later helpers retain prelaunch inventories and enforce the shared lifecycle lock. No claim is made that unrelated host contention was continuously measured or absent.

## Sensitivity, cache and advancement

| Arm | Reversed-label accepted-outcome changes /24 | Remapped-ID changes /24 | New wrong specialized routes |
|---|---:|---:|---:|
| GLiClass |15|0|0|
| DeBERTa |0|0|0|
| Qwen |2|4|0|

All six sensitivity cohorts have24 valid responses and the preselected IDs. The fixed nominee passes the stability gate. GLiClass reversal instability and Qwen diagnostic changes do not trigger a new nominee choice. Opaque-ID remapping on the specialists remains an adapter-mapping check rather than evidence that those models consume opaque IDs.

Extended the cache audit to all **309 Qwen tasks**:135 development,123 primary and51 sensitivity, including warmups/feasibility. Every task logs an initial zero-token sequence clear, evaluation of exactly its full submitted prompt token count, then untruncated release. Per-task line evidence and each log hash are retained in final-review.json. This supports runtime-reported absence of cross-request prompt-prefix reuse for these recorded cohorts, beyond only a shared-cache-disabled message. It does not claim absence of graph reuse, weight caching, warmup effects or hidden implementation behavior. Original environment flags remain unchanged; this is supplementary evidence.

The nominee fails raw intent quality, useful acceptance, zero wrong specialized routing, improvements over both reuse paths, generalist quality, binding/readiness improvement and CPU-cost gates. Completeness and stability pass. The200-request concurrency-two load gate was correctly **not attempted because its prerequisites failed**; it is not a measured load failure or a pass. No load performance claim follows.

## Material limits

- This is a stratified authored120-case pilot; aggregate accuracy is not an estimate of production traffic. Family clustering and reported uncertainty do not establish rare-error guarantees or freedom from pretraining overlap.
- CPU specialists were measured in Linux ARM64 Docker; Qwen used native Apple Silicon Metal. No matched-hardware/model-intrinsic speedup is claimed. The optional Qwen CPU probe was unattempted because the pinned historical runtime image was unavailable.
- Qwen memory is sampled native-process RSS, not total Metal/unified memory. Between-sample peaks and continuous host contention were not measured. Code timing includes its native-driver path and is not reported as a learned HTTP latency sample.
- The result supports keeping the baseline for this tested configuration and CPU operating point. It does not prove all specialist checkpoints or different task formulations are ineffective, nor authorize executing classified actions.
- Real container/process state was not re-queried by this final reviewer. Shutdown and resource conclusions here audit the preserved actual-inspection records and their consistency, rather than supplying a second live OS observation.

No material inconsistency affecting the frozen verdict was found. Preserve all raw outputs and these limitations alongside the readable report.


## Readable-report and final-cleanup cross-check

Checked the new specialist findings in `docs/validation-specialist-intent.md` and `docs/when-to-use.md` against the final metrics and supplemental execution summary. Counts, frozen configurations, sensitivity, resource/budget figures, cache wording, paired interval and withheld-load explanation agree. One wording defect was corrected by the author before this final review: each historical code arm has six native-output errors comprising four conflicting-operation errors and two unsupported-SearchOptions errors. This correction does not change any result or score.

Also checked the20 embedding example-index raw response/hash pairs and the primary-stage cached-index identity, bringing the total raw HTTP response/hash pairs checked to1,145. The example index is reused, while query outputs are retained separately. Supplemental sensitivity and remaining-budget values match the independent audit.

The final shutdown-verification record contains all13 lifecycles: ten Docker states are exited/Running=false and all three Qwen native PID probes are absent. These are author-collected live observations independently checked for consistency here. The retained check log reports76 Python tests OK with no skips, plus a cached pass for the pinned Go race checks. No heavy tests were rerun during inference.

Reviewed readable-report hashes:

- `docs/validation-specialist-intent.md`: `213afc072aaa16d3436939daebb40db6a3f98027ae57d96a846039cb9e34beae`
- `docs/when-to-use.md`: `7c2fac39fdf1a3aadddf25def7dcdccb603c9e19a0bf53b1502c77e159bd72a8`
