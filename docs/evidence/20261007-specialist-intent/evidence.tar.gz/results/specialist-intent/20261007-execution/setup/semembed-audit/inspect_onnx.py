"""Read ONNX protobuf metadata only, without loading a runtime/session/model.

ONNX ModelProto.graph=7, GraphProto.initializer=5, NodeProto.attribute=5,
AttributeProto.t=5/g=6/tensors=10/graphs=11, TensorProto.data_type=2.
The generic wire reader skips tensor raw_data rather than interpreting weights.
"""
import collections,hashlib,json,pathlib
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path.cwd()

def varint(data,pos):
 value=shift=0
 while pos<len(data):
  b=data[pos];pos+=1;value|=(b&127)<<shift
  if not b&128:return value,pos
  shift+=7
  if shift>70:raise ValueError('invalid varint')
 raise ValueError('short varint')

def fields(data):
 pos=0
 while pos<len(data):
  tag,pos=varint(data,pos);number,wire=tag>>3,tag&7
  if wire==0:value,pos=varint(data,pos)
  elif wire in (1,5):
   end=pos+(8 if wire==1 else 4);value=data[pos:end];pos=end
  elif wire==2:
   size,pos=varint(data,pos);end=pos+size
   if end>len(data):raise ValueError('short field')
   value=data[pos:end];pos=end
  else:raise ValueError('unsupported wire '+str(wire))
  yield number,value

def text(v):return bytes(v).decode()

def tensor(data):
 d=dict(fields(data));dtype=d.get(2)
 return {'name':text(d.get(8,b'')),'data_type':dtype,'external_data':14 in d,'data_location':d.get(14,0)}

def graph(data):
 tensors=[];ops=[]
 for number,value in fields(data):
  if number==5:tensors.append(tensor(value))
  elif number==1:
   for n,v in fields(value):
    if n==4:ops.append(text(v))
    elif n==5:
     for an,av in fields(v):
      if an in (5,10):tensors.append(tensor(av))
      elif an in (6,11):
       t,o=graph(av);tensors+=t;ops+=o
 return tensors,ops

lock=json.loads((ROOT/'docs/evidence/20261005-synthesis-acquisition/provenance/embedding-files.json').read_text())
path=ROOT/lock['files'][0]['artifact'];raw=path.read_bytes();mf=dict(fields(memoryview(raw)))
tensors,ops=graph(mf[7]);types=collections.Counter(t['data_type'] for t in tensors)
report={'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),
        'ir_version':mf.get(1),'producer_name':text(mf.get(2,b'')),'producer_version':text(mf.get(3,b'')),
        'tensor_count':len(tensors),'tensor_datatype_counts':dict(types),'operator_counts':dict(collections.Counter(ops)),
        'external_tensors':sum(t['external_data'] for t in tensors),
        'precision':'FP32' if 1 in types and set(types)<={1,6,7,9} and not any('Quantiz' in op or op in ('MatMulInteger','QLinearMatMul') for op in ops) else 'unresolved',
        'interpretation':'Every serialized floating tensor is TensorProto.FLOAT (1); integer/bool constants do not imply quantized weights; no quantization operators.',
        'runtime_executed':False,'parser':'inspect_onnx.py generic protobuf wire parser; no ONNX Python package available'}
(OUT/'onnx-metadata.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
