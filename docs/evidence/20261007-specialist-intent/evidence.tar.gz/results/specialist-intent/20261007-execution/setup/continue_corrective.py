import json, os, pathlib, shutil, subprocess, sys, time

REPO = pathlib.Path('/Users/coby/Code/c360/semselect')
SOURCE = REPO/'eval/specialist-intent'
OUT = REPO/'results/specialist-intent/20261007-execution/setup/corrective'
# Existing corrective dependency closure; continuing after harness metadata fix.
BASE = 'python@sha256:bf44cdfcb76cd3b41e879bc058fc37ec5872002ccfde7fcb765e218cde0cd79c'
started = time.monotonic()
deadline = started + 1250
events = []

def run(command, label, seconds=1200):
    before = time.monotonic()
    with (OUT/(label+'.log')).open('x') as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=min(seconds, max(1, deadline-before)))
            events.append({'stage': label, 'command': command, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic()-before})
            if result.returncode:
                raise RuntimeError(label+' failed; see its retained log')
        finally:
            (OUT/'continuation-events.json').write_text(json.dumps(events,indent=2)+'\n')

try:
    run([sys.executable,str(SOURCE/'locks/prepare.py'),'wheels','--wheelhouse',str(OUT/'wheels'),'--output',str(OUT/'requirements.lock.txt')],'wheel-lock-after-harness-fix',60)
    context=OUT/'context'
    context.mkdir()
    for name in ('Dockerfile','adapters.py','preflight.py','server.py'):
        shutil.copyfile(SOURCE/name,context/name)
    shutil.copytree(SOURCE/'locks',context/'locks')
    shutil.copytree(OUT/'wheels',context/'wheels')
    shutil.copyfile(OUT/'requirements.lock.txt',context/'requirements.lock.txt')
    run(['docker','build','--platform','linux/arm64','--build-arg','PYTHON_IMAGE='+BASE,'--iidfile',str(OUT/'image.id'),'-t','semselect-specialist:20261007',str(context)],'image-build')
    for arm in ('gliclass','deberta'):
        run([sys.executable,str(SOURCE/'locks/prepare.py'),'model','--arm',arm,'--output',str(OUT/'models'/arm)],arm+'-acquire')
    status='prepared'
except BaseException as error:
    status='failed: '+str(error)
    raise
finally:
    (OUT/'continuation-result.json').write_text(json.dumps({'status':status,'base_image':BASE,'elapsed_seconds':time.monotonic()-started,'shared_environment_setup_counts_against_each_specialist':True,'events':events},indent=2)+'\n')
