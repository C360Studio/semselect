# Specialist intent pilot

**Verdict: keep the baseline**

Development nominee: deberta. Stratified authored pilot; aggregate accuracy is not production traffic accuracy.

| Arm | Raw correct /120 | Correct accepted | Wrong accepted | Deferred | Errors | Unattempted | Complete correct | Executable correct | Native complete correct |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| keyword | 61 | 61 | 53 | 0 | 6 | 0 | 61 | 33 | 37 |
| keyword_bm25_default | 61 | 61 | 53 | 0 | 6 | 0 | 61 | 33 | 37 |
| keyword_bm25_tuned | 61 | 61 | 53 | 0 | 6 | 0 | 61 | 33 | 37 |
| improved_rules | 95 | 95 | 25 | 0 | 0 | 0 | 95 | 45 | 0 |
| embeddings | 34 | 0 | 0 | 120 | 0 | 0 | 0 | 0 | 0 |
| gliclass | 37 | 37 | 83 | 0 | 0 | 0 | 37 | 27 | 0 |
| deberta | 22 | 13 | 1 | 106 | 0 | 0 | 13 | 11 | 0 |
| qwen | 111 | 111 | 8 | 1 | 0 | 0 | 111 | 60 | 0 |

Native full-output counts apply only where native SearchOptions were available; missing native output is not a measured zero-quality model result.

## Screening gates

- nomination: pass
- completeness: pass
- intent_quality: not met
- useful_acceptance: not met
- wrong_specialized_routing: not met
- added_value: not met
- generalist_quality: not met
- binding_readiness: not met
- cpu_service_cost: not met
- stability: pass
- small_load: not met

Per-intent recall, no_override strata, coverage, confusion matrices, native scores, paired corrections/regressions and clustered uncertainty are preserved in summary.json and the immutable raw stage journals.

## Limits

- No calibration guarantee
- No production-traffic distribution claim
- No freedom from pretraining overlap claim
- CPU specialists versus Metal Qwen is an operating-point comparison
- ID remapping on backends without opaque IDs is adapter-only sensitivity
- Offline tests establish harness behavior, not inference quality

No classification authorizes execution. A prototype recommendation requires every gate, including the nominee-only load check. Incomplete runtime, missing telemetry or unresolved fixture defects cannot establish a win.
