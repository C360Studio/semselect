# Independent pre-execution payload and scoring review

Status: **PASS for prepared fixtures, payloads, binder and scoring**, bound to the exact preparation freeze below. Reviewer: `/root/label_review`, separate from the fixture author and implementation/tuning owners. No candidate/model outputs were inspected. The reviewer edited only `review.json` and this record in the run directory; no frozen source or fixture was changed.

Preparation freeze SHA-256: `5374ff31adda4938c4d02ceb1dc09633d6518bedd6911173fa2c9d211166177a`.

Request manifest SHA-256: `c9d9b06aab4ea47e7c7ff150b49d4dfd2d2757607fc6db1d7ad076f30097a16c`.

## Evidence checked

- All 52 frozen source hashes match both current sources and preserved run source copies. The source-file set also matches the preparation manifest. No development, primary, sensitivity or load stage existed when audited.
- The exact fixture bytes match the earlier independent review: development `d3b9f9d54b8bd8e191f183a198be75aeb08a09800453fb4d4ed7e5d49896d0b3`, heldout `e1e6f88099fc2935797aac2d803c9ec9245872ef706a9c8c96cb2bc787267ba5`. That review covered all 180 semantic labels, binding/readiness/options, subgroup counts, family separation corrections and preselected subsets. No heldout query text or per-case gold is disclosed here.
- Independently audited all 1,568 manifest entries, their payload hashes, split/variant/view identities, complete expected Cartesian coverage, and arm-specific extracted manifest copies. This comprises 456 prepared payloads per decision model and 200 embedding payloads including the 20 frozen training examples. Both heldout variants are prepared but the runner executes only the development-selected variant.
- Model wire payloads contain only the query, equivalent fixed operation semantics, approved variant instructions and runtime formatting. They contain no fixture IDs/families/provenance, gold, rationales or other arm outputs. Qwen has constrained operation/defer JSON, thinking disabled, no generated confidence, and a 64-token output bound.
- Reverse-order and reversible opaque-ID views preserve the semantic description mapping and decode to the canonical operations. The 24-case sensitivity subset remains preselected. Specialist opaque-ID remapping is accurately described as adapter mapping only.
- The single frozen binder was mechanically checked against all 180 independently reviewed gold outputs: 180 agreements, no invented binding required. The implementation preserves partial options and non-executable needs_binding separately from no_override and caller deferral.
- Reviewed scoring implementation and protocol: raw and accepted accuracy, complete output/executable correctness, wrong specialized routing, explicit error/unattempted denominators, development-only configuration/nominee/baseline selection, fixed ties, both-baseline improvement gates, full cohort latency samples, missing-resource failure, sensitivity outcomes, concurrency advancement gate and family-cluster intervals remain separate. Native code options are reported separately from shared-binder outputs.
- Ran 59 offline tests: adapters, binder, scoring, preflight, fixtures, environment evidence and runner all passed. Command: `PYTHONPATH=eval/specialist-intent python3 -m unittest test_adapters test_binder test_scoring test_preflight test_fixtures test_evidence test_runner -v`. These use synthetic responses and cannot establish model quality.
- Reviewed the supplied exact specialist token manifests mechanically against every prepared payload and the pinned model artifact identities. GLiClass: 456 records, full combined input lengths 282–333. DeBERTa: 456 records, all nine complete premise/hypothesis pairs present per record, maximum-pair lengths 168–219. All fit the 512-token bound with verified no-truncation records. Manifest hashes: GLiClass `72171d2efce610fd2c3428a73be6d742d102d52f33102111010faccf6d27dec5`; DeBERTa `95fa62cb75c96fad44652e488e4ce028812492c5f5fc78d8ee74607ff33e1288`. This reviewer inspected the records and tokenization code, rather than rerunning the actual tokenizer containers.

## Scope of approval

The required independent fixture/payload/scoring flags are justified for this preparation freeze. This permits the user-authorized bounded staged run to proceed subject to the existing per-stage checks. It is not a runtime qualification, a promotion verdict, or permission to skip required environment/token evidence.

The supplied specialist image identifier is `sha256:7db4b05ba0eaf9d677935ccc93f6396c1693c94971bc8405d5fdc9ebee6f44b5`; its actual live image/limits/endpoint must still be checked by the harness and measured environment record at each stage. This reviewer did not launch or inspect that image. Qwen and embedding full-input token records were not yet supplied; their gates must pass before those calls. Retain setup corrections, readiness/startup/resource observations, one-loaded-model discipline, cumulative budgets, supervised shutdown and cleanup evidence. No inference, latency, memory or accuracy claim is made by this review.

All heldout text/gold remains restricted to fixture/review access. Any subsequent semantic source/fixture changes invalidate this approval until a new explicit freeze and independent review are recorded.
