#!/usr/bin/env python3
"""Bounded, model-free artifact/runtime preparation for the smaller Qwen experiment."""
import concurrent.futures, hashlib, json, os, pathlib, shutil, signal, subprocess, sys, time, traceback, urllib.request
ROOT=pathlib.Path('/Users/coby/Code/c360/semselect')
OUT=ROOT/'results/qwen-size/20261007/setup/runtime'
LOCKS=ROOT/'eval/qwen-size/locks'
START=json.loads((OUT/'setup-start.json').read_text())['start_unix']
DEADLINE=START+1800
LOG=ROOT/'.enjoy-logs/qwen-size-setup-runtime-20261007.log'
LOG.parent.mkdir(exist_ok=True)
print('PID',os.getpid(),flush=True)
f=LOG.open('x');os.dup2(f.fileno(),1);os.dup2(f.fileno(),2)
print(json.dumps({'pid':os.getpid(),'start_unix':START,'deadline_unix':DEADLINE}),flush=True)

def dump(path,obj): path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def remaining():
    r=DEADLINE-time.time()
    if r<=0: raise TimeoutError('shared 30-minute model setup budget exhausted')
    return r

def download(url,path):
    start=time.time(); h=hashlib.sha256(); size=0
    req=urllib.request.Request(url,headers={'User-Agent':'semselect-bounded-evaluation/1'})
    with urllib.request.urlopen(req,timeout=min(60,remaining())) as res, path.open('xb') as out:
        while True:
            remaining(); chunk=res.read(1024*1024)
            if not chunk: break
            out.write(chunk);h.update(chunk);size+=len(chunk)
    result={'url':url,'path':str(path.relative_to(ROOT)),'sha256':h.hexdigest(),'size_bytes':size,'seconds':time.time()-start}
    print(json.dumps(result),flush=True)
    return result

def models(key):
    meta=json.loads((OUT/(key+'-metadata.json')).read_text());repo=meta['id'];rev=meta['sha']
    target=next(v for v in meta['siblings'] if v['rfilename'].lower().endswith('q4_k_m.gguf'))
    modeldir=OUT/key;modeldir.mkdir(exist_ok=True)
    provenance=[]
    provenance.append(download(f'https://huggingface.co/{repo}/resolve/{rev}/README.md',modeldir/'README.md'))
    source=meta['cardData']['base_model'];source=source[0] if isinstance(source,list) else source
    upstream=download('https://huggingface.co/api/models/'+source+'?blobs=true',modeldir/'upstream-metadata.json');provenance.append(upstream)
    up=json.loads((modeldir/'upstream-metadata.json').read_text())
    for name in ['README.md','LICENSE']:
        provenance.append(download(f'https://huggingface.co/{source}/resolve/{up["sha"]}/{name}',modeldir/('upstream-'+name)))
    lock={'repository':repo,'revision':rev,'filename':target['rfilename'],'size_bytes':target['size'],'sha256':target['lfs']['sha256'],'license':'Apache-2.0','alias':key.replace('_','-'),'source_repository':source,'source_current_revision':up['sha'],'source_revision_note':'GGUF publisher identifies upstream model but does not pin the conversion source revision. source_current_revision is acquired provenance, not a claimed conversion source. Distributed GGUF bytes are pinned above.','runtime_revision':'6c59c40076c00eab49754dc955d7652d93f9e125','metadata_source':f'https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true','precision':'Q4_K_M','artifact_path':str((modeldir/target['rfilename']).relative_to(ROOT)),'provenance':provenance}
    dump(LOCKS/(key+'.json'),lock)
    artifact=download(f'https://huggingface.co/{repo}/resolve/{rev}/{target["rfilename"]}',modeldir/target['rfilename'])
    if artifact['sha256']!=lock['sha256'] or artifact['size_bytes']!=lock['size_bytes']: raise ValueError(key+' artifact bytes failed locked SHA256/size')
    dump(modeldir/'verified.json',{'verified':True,'artifact':artifact,'setup_elapsed_seconds':time.time()-START})
    return {'status':'ready','key':key,'artifact':artifact,'lock':str((LOCKS/(key+'.json')).relative_to(ROOT))}

def command(argv,log):
    begin=time.time()
    with log.open('xb') as f:
        p=subprocess.Popen(argv,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=p.wait(timeout=remaining())
        except BaseException:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
            raise
    event={'argv':argv,'elapsed_seconds':time.time()-begin,'exit_code':code,'log':str(log.relative_to(ROOT))}
    print(json.dumps(event),flush=True)
    if code:raise RuntimeError('command failed: '+str(event))
    return event

def runtime():
    shutil.copyfile(ROOT/'Dockerfile',OUT/'Dockerfile')
    commands=[]
    cmd=['docker','build','--platform','linux/arm64','--target','runtime','--progress','plain','--iidfile',str(OUT/'image.id'),'-t','semselect-qwen-size-runtime:20261007','.']
    commands.append(command(cmd,OUT/'build.log'))
    image=(OUT/'image.id').read_text().strip()
    commands.append(command(['docker','image','inspect',image],OUT/'image-inspect.json'))
    probe="printf 'ARCHITECTURE\\n'; uname -m; printf '\\nRUNTIME FILES\\n'; find /opt/llama -type f -exec sha256sum {} +; printf '\\nSYMLINKS\\n'; find /opt/llama -type l -printf '%p -> %l\\n'; printf '\\nDEPENDENCIES\\n'; dpkg-query -W -f='${Package} ${Version}\\n'; printf '\\nLDD\\n'; ldd /opt/llama/llama-server"
    commands.append(command(['docker','run','--rm','--platform','linux/arm64','--network','none','--entrypoint','/bin/sh',image,'-c',probe],OUT/'runtime-provenance.txt'))
    doc={'status':'ready','image':image,'architecture':'linux/arm64','runtime_revision':'6c59c40076c00eab49754dc955d7652d93f9e125','source_tarball_sha256':'efe5ae8270793300807cd2c0e20e748816f2c153971ce5610450f0e6a23d214e','dockerfile_sha256':hashlib.sha256((OUT/'Dockerfile').read_bytes()).hexdigest(),'commands':commands,'model_loaded':False,'setup_elapsed_seconds':time.time()-START}
    dump(LOCKS/'runtime.json',doc);return doc

results={}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    jobs={pool.submit(models,key):key for key in ('qwen35_2b','qwen3_17b')};jobs[pool.submit(runtime)]='runtime'
    for future in concurrent.futures.as_completed(jobs):
        key=jobs[future]
        try:results[key]=future.result()
        except BaseException as exc: results[key]={'status':'failed','exception':repr(exc),'traceback':traceback.format_exc()}
        dump(OUT/'setup-results.json',{'results':results,'elapsed_seconds':time.time()-START,'maximum_seconds':1800})
        print(json.dumps({key:results[key]}),flush=True)
sys.exit(0 if all(v['status']=='ready' for v in results.values()) else 1)
